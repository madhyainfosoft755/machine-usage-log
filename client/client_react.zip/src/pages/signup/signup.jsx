const SignUp = () => {
    return <></>
}

export default SignUp